package lab8.step1;

import java.util.ArrayList;

public class main {
  public static void main(String[] args) {
    double[][] points = {{-1, 0}, {-1, -1}, {4, 1}, {2, 0.5}, {3.5, 2}, {3, 1.5}, {-1.5, 4}, {5.5, 4}};

    ArrayList<Point> points2 = new ArrayList<>();

    for(double[] point:points) {
      points2.add(new Point(point[0], point[1]));
    }

    for(int i = 0; i < points2.size(); ++i) {
      Point base = points2.get(i);
      double cur = Double.MAX_VALUE;
      Point closest = null;
      for(int j = 0; j < points2.size(); ++j) {
        Point target = points2.get(j);
        double diff = base.compareCoordinate(target);
        if(diff == 0) continue;
        // System.out.println("{ " + target.getX() + "," + target.getY() + " } & " + "{ " + base.getX() + "," + base.getY() + " } | " + diff);
        if(diff < cur) {
          closest = target;
          cur = diff;
        }
      }

      if(closest != null)
        System.out.println("{ " + closest.getX() + "," + closest.getY() + " }");
    }

    return;
  }
}
