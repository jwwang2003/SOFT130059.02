package com.example.lab10.gamelogic.vectorspace;

public interface XComponent {
  int getX();
}