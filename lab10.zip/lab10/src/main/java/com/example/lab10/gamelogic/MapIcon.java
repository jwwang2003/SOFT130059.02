package com.example.lab10.gamelogic;

import javafx.scene.image.Image;

public interface MapIcon {
    Image getImage();
}