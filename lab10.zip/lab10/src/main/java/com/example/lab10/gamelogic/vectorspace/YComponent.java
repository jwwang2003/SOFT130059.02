package com.example.lab10.gamelogic.vectorspace;

public interface YComponent {
  int getY();
}