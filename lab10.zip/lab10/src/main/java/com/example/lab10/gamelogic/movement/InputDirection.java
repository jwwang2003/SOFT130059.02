package com.example.lab10.gamelogic.movement;

public enum InputDirection {
  h,  // left
  j,  // down
  k,  // up
  l,  // right
}