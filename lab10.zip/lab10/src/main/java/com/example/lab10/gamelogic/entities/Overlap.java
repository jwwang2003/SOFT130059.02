package com.example.lab10.gamelogic.entities;

public interface Overlap {
}
