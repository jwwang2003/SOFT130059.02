package com.example.lab10.gamelogic.vectorspace;

public interface ZComponent {
  int getZ();
}