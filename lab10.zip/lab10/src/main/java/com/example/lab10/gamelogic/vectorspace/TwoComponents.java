package com.example.lab10.gamelogic.vectorspace;

public abstract class TwoComponents implements XComponent, YComponent {
  public abstract int getX();
  public abstract int getY();
}