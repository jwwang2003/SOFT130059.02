package com.example.lab10.gamelogic.movement;

public enum Direction {
  up, down, left, right
}