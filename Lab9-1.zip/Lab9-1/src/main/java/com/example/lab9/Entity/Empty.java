package com.example.lab9.Entity;

/**
 * @author zhsyy
 * @version 1.0
 * @date 2023/5/17 10:35
 */

public class Empty extends Element{
    public Empty(EntityIcons entityIcons) {
        this.entityIcons = entityIcons;
    }

}
