package com.example.lab9.Entity;

/**
 * @author zhsyy
 * @version 1.0
 * @date 2023/5/17 10:34
 */

public class Wall extends Element{

    public Wall(EntityIcons entityIcons) {
        this.entityIcons = entityIcons;
    }
}
