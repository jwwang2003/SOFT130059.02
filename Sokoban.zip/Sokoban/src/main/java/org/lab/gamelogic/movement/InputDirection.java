package org.lab.gamelogic.movement;

public enum InputDirection {
  h,  // left
  j,  // down
  k,  // up
  l,  // right
}