package org.lab.gamelogic.vectorspace;

public interface YComponent {
  int getY();
}