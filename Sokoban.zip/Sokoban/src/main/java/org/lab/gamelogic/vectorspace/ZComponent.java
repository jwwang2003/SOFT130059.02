package org.lab.gamelogic.vectorspace;

public interface ZComponent {
  int getZ();
}