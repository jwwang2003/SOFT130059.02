package org.lab.gamelogic.movement;

public enum Direction {
  up, down, left, right
}