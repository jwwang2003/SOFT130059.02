package org.lab.gamelogic.entities;

public interface Stationary {
}
