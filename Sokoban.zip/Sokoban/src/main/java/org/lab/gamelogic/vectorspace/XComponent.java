package org.lab.gamelogic.vectorspace;

public interface XComponent {
  int getX();
}